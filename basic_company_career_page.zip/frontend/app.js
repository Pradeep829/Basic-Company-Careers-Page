angular
  .module("myApp", ["ngRoute"])

  .config(function ($routeProvider, $locationProvider) {
    $routeProvider
      .when("/homepage", {
        template: "<homepage-section></homepage-section>",
        controller: "HomeController",
      })
      .when("/homepage/services", {
        template: '<services-section></services-section>',
        controller: 'ServicesController'

      })
      .when("/homepage/features", {
        template: '<features-section></features-section>',
        controller: 'FeaturesController'
      })
      .when("/homepage/career", {
        template: '<careers-section class="careers-main"></careers-section>',
      })

      .otherwise({
        redirectTo: "/homepage",
      }); // Optional if you want clean URLs without hash // $locationProvider.html5Mode(true);
  })

  .controller("MainController", function ($scope) {})

  .controller("HomeController", function ($scope) {
    $scope.doSomething = function () {
      alert("Button Clicked");
    };
  })

.controller("ServicesController", function ($scope) {})
.controller("FeaturesController", function ($scope) {})


