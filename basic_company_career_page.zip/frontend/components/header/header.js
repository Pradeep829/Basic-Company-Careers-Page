angular.module('myApp')
  .component('headerComponent', {
    templateUrl: 'components/header/header.html',
    controller: function($scope) {
      var ctrl = this;
      ctrl.activeSection = '';
      ctrl.mobileMenuVisible = false;

      ctrl.setActive = function(section) {
        ctrl.activeSection = section;
      };

      ctrl.toggleMobileMenu = function() {
        ctrl.mobileMenuVisible = !ctrl.mobileMenuVisible;
      };

      ctrl.closeMobileMenu = function() {
          ctrl.mobileMenuVisible = false;
      }
    }
  });