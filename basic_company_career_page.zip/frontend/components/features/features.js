angular.module('myApp')
.component('featuresSection', {
    templateUrl: 'components/features/features.html',
    controller: function() {
        this.performanceFeatures = [
            {
                icon: '⚡',
                title: 'Blazing Speed',
                description: 'Super-fast load times and optimized performance.',
            },
            {
                icon: '🚀',
                title: 'Smooth Animations',
                description: 'Micro-interactions for delightful UX.',

            },
            {
                icon: '⏱️',
                title: 'Quick Start',
                description: 'Pre-built templates and starter kits.',
            }
        ];

        this.securityFeatures = [
            {
                icon: '🔒',
                title: 'Data Encryption',
                description: 'All sensitive data is securely encrypted.',
            },
            {
                icon: '🛡️',
                title: 'Fraud Prevention',
                description: 'Protecting your app from malicious attacks.',

            },
            {
                icon: '🔑',
                title: 'Secure Login',
                description: 'Strong authentication protocols.',
            }
        ];

        this.designFeatures = [
            {
                icon: '🎨',
                title: 'Theme Customization',
                description: 'Easily adjust colors, typography, and layouts.',

            },
            {
                icon: '🖌️',
                title: 'Icon Packs',
                description: 'Beautiful icon libraries included.',
            },
            {
                icon: '📱',
                title: 'Responsive UI',
                description: 'Perfect layouts for mobile, tablet, and desktop.',
            }
        ];

        this.scalabilityFeatures = [
            {
                icon: '🌍',
                title: 'Multi-Region Hosting',
                description: 'Deploy your app worldwide without latency.',
            },
            {
                icon: '📈',
                title: 'Analytics Ready',
                description: 'Built-in analytics dashboards.',
              
            },
            {
                icon: '🤝',
                title: 'Third-Party Integrations',
                description: 'Easily integrate with other services.',
            }
        ];
    },
    controllerAs: '$ctrl'
});
