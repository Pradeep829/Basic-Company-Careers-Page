angular.module('myApp')
    .component('careersSection', {
        templateUrl: 'components/careers/careers.html',
        controller: function($http) {
            var ctrl = this;
            ctrl.careers = [];
            ctrl.showModal = false;
            ctrl.newCareer = {};
            ctrl.modalType = 'add';
            ctrl.jdModal = false;
            ctrl.jdContent = '';
            ctrl.loading = true; // Add loading state

            ctrl.fetchCareers = function() {
                ctrl.loading = true; // Start loading
                $http.get('https://manualwebsite.netlify.app/.netlify/functions/career')
                    .then(function(response) {
                        ctrl.careers = response.data;
                    })
                    .catch(function(error) {
                        console.error('Error fetching careers:', error);
                        alert('Error fetching careers. Please try again.');
                    })
                    .finally(function() {
                        ctrl.loading = false; // End loading
                    });
            };

            ctrl.openModal = function() {
                ctrl.showModal = true;
                ctrl.modalType = 'add';
                ctrl.newCareer = {};
            };

            ctrl.editCareer = function(career) {
                ctrl.showModal = true;
                ctrl.modalType = 'edit';
                ctrl.newCareer = angular.copy(career);
            };

            ctrl.closeModal = function() {
                ctrl.showModal = false;
                ctrl.jdModal = false;
            };

            ctrl.submitCareer = function() {
                var httpPromise;
                if (ctrl.modalType === 'add') {
                    httpPromise = $http.post('https://manualwebsite.netlify.app/.netlify/functions/career', ctrl.newCareer);
                } else if (ctrl.modalType === 'edit') {
                    httpPromise = $http.put('https://manualwebsite.netlify.app/.netlify/functions/career?id=' + ctrl.newCareer.id, ctrl.newCareer);
                }

                httpPromise.then(function() {
                    ctrl.closeModal();
                    ctrl.fetchCareers();
                    alert('Career ' + (ctrl.modalType === 'add' ? 'added' : 'updated') + ' successfully!');
                }).catch(function(error){
                    console.error("Error submitting career", error);
                    alert('Error ' + (ctrl.modalType === 'add' ? 'adding' : 'updating') + ' career. Please try again.');
                });
            };

            ctrl.deleteCareer = function(id) {
                $http.delete('https://manualwebsite.netlify.app/.netlify/functions/career?id=' + id)
                    .then(function() {
                        ctrl.fetchCareers();
                        alert('Career deleted successfully!');
                    }).catch(function(error){
                        console.error("Error deleting career", error);
                        alert('Error deleting career. Please try again.');
                    });
            };

            ctrl.viewJD = function(jobDescription) {
                ctrl.jdContent = jobDescription;
                ctrl.jdModal = true;
            };

            ctrl.fetchCareers();
        }
    });