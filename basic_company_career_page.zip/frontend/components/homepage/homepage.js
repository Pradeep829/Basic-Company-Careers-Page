

// homepage.js
angular.module('myApp')
.directive('slickCarousel', function() {
  return {
    restrict: 'E',
    template: '<div class="slick"></div>',
    scope: {
      slides: '='
    },
    link: function(scope, element, attrs) {
      scope.$watch('slides', function(newVal, oldVal) {
        if (newVal) {
          element.find('.slick').empty();

          angular.forEach(scope.slides, function(slide) {
            element.find('.slick').append('<div><h3>' + slide.title + '</h3><p>' + slide.description + '</p></div>');
          });

          $(element).find('.slick').slick({
            autoplay: true,
            autoplaySpeed: 3000,
            dots: true,
            infinite: true,
          });
        }
      });
    }
  };
})
.component('homepageSection', {
  templateUrl: 'components/homepage/homepage.html',
  controller: function($scope,  $location) {
    $scope.hero = {
      headline: 'Welcome to Innovate Solutions',
      subheading: 'Transforming businesses with cutting-edge technology.',
      ctaText: 'Explore Our Careers',
      ctaAction: function() {
        $location.path('homepage/career');
      }
    };

    $scope.slickSlides = [
      {
        title: 'Introducing Our Innovative Solutions',
        description: 'We specialize in developing cutting-edge technology that empowers businesses to streamline operations and enhance customer engagement. Discover how our solutions can transform your industry.'
      },
      {
        title: 'Our Commitment to Sustainable Practices',
        description: 'We believe in building a better future through sustainable initiatives. Learn about our eco-friendly practices and how we contribute to a greener planet. Join us in making a positive impact.'
      },
      {
        title: 'Empowering Your Team with Expert Training',
        description: 'Invest in your team’s growth with our comprehensive training programs. We offer tailored courses designed to enhance skills, boost productivity, and drive innovation. Equip your workforce for success.'
      },
      {
        title: 'Customer-Centric Support You Can Trust',
        description: 'Our dedicated support team is here to assist you every step of the way. Experience prompt and reliable assistance that ensures your satisfaction. We prioritize your success and strive to exceed your expectations.'
      },
      {
        title: 'Join Our Growing Community of Partners',
        description: 'Become a part of our thriving network of partners and collaborators. Together, we can unlock new opportunities and achieve remarkable results. Explore the benefits of partnering with us and grow your business.'
      }
    ];

    $scope.services = [
      {
        title: 'Cloud Infrastructure Services',
        description: 'Comprehensive cloud solutions including IaaS, PaaS, and SaaS, tailored to your specific needs. We manage your infrastructure, allowing you to focus on your core business.'
      },
      {
        title: 'Data Analytics and Business Intelligence',
        description: 'Transform raw data into actionable insights with our advanced analytics tools and business intelligence solutions. We help you make informed decisions.'
      },
      {
        title: 'Cybersecurity and Network Security',
        description: 'Protect your digital assets with our robust cybersecurity services, including threat detection, vulnerability assessments, and incident response.'
      },
      {
        title: 'Custom Software Development and Integration',
        description: 'Design and develop custom software solutions that integrate seamlessly with your existing systems. We build applications that enhance your productivity.'
      },
      {
        title: 'Digital Marketing and SEO Services',
        description: 'Boost your online visibility and drive targeted traffic to your website with our digital marketing and SEO strategies. We help you reach your audience.'
      },
      {
        title: 'Managed IT Services',
        description: 'Outsource your IT management to our team of experts. We provide proactive monitoring, maintenance, and support to ensure your systems run smoothly.'
      },
      {
        title: 'Mobile Application Development',
        description: 'Create engaging and user-friendly mobile applications for iOS and Android platforms. We design apps that enhance your customer experience.'
      },
      {
        title: 'E-commerce Solutions',
        description: 'Build and manage your online store with our comprehensive e-commerce solutions. We provide tools for product management, payment processing, and order fulfillment.'
      },

    ];

    $scope.features = [
      {
        title: 'Real-Time Monitoring and Alerting',
        description: 'Monitor your systems and applications in real-time with our advanced monitoring tools. Receive instant alerts for critical issues.'
      },
      {
        title: 'Automated Backup and Disaster Recovery',
        description: 'Ensure your data is protected with our automated backup and disaster recovery solutions. We minimize downtime and data loss.'
      },
      {
        title: 'API Integration and Development',
        description: 'Connect your applications and services with our API integration and development expertise. We build seamless integrations.'
      },
      {
        title: 'Scalable and Flexible Architecture',
        description: 'Our solutions are built on a scalable and flexible architecture that can adapt to your changing business needs. We grow with you.'
      },
      {
        title: 'User-Friendly Interface and Experience',
        description: 'Provide your users with an intuitive and engaging experience with our user-friendly interface and experience design.'
      },
      {
        title: 'Data Encryption and Security',
        description: 'Protect your sensitive data with our advanced encryption and security measures. We ensure your data is safe and secure.'
      },
      {
        title: 'Cloud-Based Collaboration Tools',
        description: 'Enhance team collaboration with our cloud-based collaboration tools. We provide platforms for communication, file sharing, and project management.'
      },
      {
        title: 'Custom Reporting and Dashboards',
        description: 'Gain insights into your business performance with our custom reporting and dashboards. We provide visualizations and analytics.'
      },
      {
        title: 'Mobile Access and Synchronization',
        description: 'Access your data and applications from anywhere with our mobile access and synchronization features. We keep you connected.'
      },
      {
        title: '24/7 Technical Support and Maintenance',
        description: 'Receive round-the-clock support and maintenance from our dedicated team. We ensure your systems are running smoothly.'
      }
    ];
  }
});