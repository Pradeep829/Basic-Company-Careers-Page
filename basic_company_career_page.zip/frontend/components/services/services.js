angular.module('myApp')
.component('servicesSection', {
    templateUrl: 'components/services/services.html',
    controller: function() {
        this.sections = [
            {
                title: 'Web Development',
                intro: 'We create responsive, scalable websites with cutting-edge technologies.',
                items: [
                    { name: 'Frontend Development', description: 'Building stunning UIs with React, Angular, and Vue.',},
                    { name: 'Backend Development', description: 'Powerful APIs and backend with Node.js and Django.',  },
                    { name: 'Full Stack Solutions', description: 'End-to-end web app solutions.',  }
                ]
            },
            {
                title: 'Mobile Application Development',
                intro: 'We design and develop world-class mobile apps.',
                items: [
                    { name: 'iOS Apps', description: 'Swift-based native iOS apps.', },
                    { name: 'Android Apps', description: 'Native Android apps with Kotlin and Java.', },
                    { name: 'Flutter Development', description: 'Cross-platform apps with Flutter.',  }
                ]
            },
            {
                title: 'UI/UX & Branding',
                intro: 'We make brands stand out with smart design.',
                items: [
                    { name: 'Wireframing', description: 'Clear structures for effortless navigation.', },
                    { name: 'Visual Design', description: 'Attractive, professional UI design.', },
                    { name: 'Brand Identity', description: 'Logos, color palettes & design systems.',  }
                ]
            },
            {
                title: 'Cloud & DevOps Solutions',
                intro: 'We help scale your business with cloud and automation.',
                items: [
                    { name: 'AWS / Azure Deployment', description: 'Scalable, reliable cloud infrastructure.',  },
                    { name: 'CI/CD Pipelines', description: 'Automate testing and deployments.',  },
                    { name: 'Monitoring & Security', description: '24/7 monitoring and secured solutions.',}
                ]
            }
        ];
    }
});
