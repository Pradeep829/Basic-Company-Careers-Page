let careers = [
    {
        id: 1,
        title: 'Frontend Developer',
        description: 'Build and maintain the frontend of our web applications',
        location: 'Remote',
        experience: '3+ years',
        jobDescription: 'Work on user-facing features, collaborate with designers.'
    },
    {
        id: 2,
        title: 'Software Engineer',
        description: 'Develop and maintain software applications and write clean code.',
        location: 'Hybrid',
        experience: '5+ years',
        jobDescription: 'Design, develop, and test software solutions, participate in code reviews, and troubleshoot issues.'
    },
    {
        id: 3,
        title: 'Marketing Manager',
        description: 'Develop and execute marketing strategies to drive brand awareness.',
        location: 'On-site',
        experience: '4+ years',
        jobDescription: 'Manage campaigns, conduct market research, and collaborate with sales to achieve marketing goals.'
    },
    {
        id: 4,
        title: 'Data Analyst',
        description: 'Analyze data to extract insights and support business decisions.',
        location: 'Remote',
        experience: '2+ years',
        jobDescription: 'Process data, create visualizations, and generate reports to communicate findings to stakeholders.'
    },
    {
        id: 5,
        title: 'Human Resources Specialist',
        description: 'Manage recruitment, onboarding, and employee relations.',
        location: 'On-site',
        experience: '3+ years',
        jobDescription: 'Handle HR policies, administer benefits, and resolve employee conflicts.'
    },
    {
        id: 6,
        title: 'Project Manager',
        description: 'Plan and execute projects to ensure timely and within-budget completion.',
        location: 'Hybrid',
        experience: '6+ years',
        jobDescription: 'Define project scope, manage resources, and communicate with stakeholders.'
    },
    {
        id: 7,
        title: 'Customer Service Representative',
        description: 'Provide customer support and resolve inquiries.',
        location: 'Remote',
        experience: '1+ years',
        jobDescription: 'Respond to customer inquiries, document interactions, and escalate issues as needed.'
    },
    {
        id: 8,
        title: 'UI/UX Designer',
        description: 'Design user interfaces and experiences for web and mobile applications.',
        location: 'Remote',
        experience: '3+ years',
        jobDescription: 'Create wireframes, prototypes, and high-fidelity designs, and conduct user research.'
    },
    {
        id: 9,
        title: 'Full Stack Developer',
        description: 'Develop both front-end and back-end components of web applications.',
        location: 'Remote',
        experience: '5+ years',
        jobDescription: 'Design and implement APIs, manage databases, and optimize applications for performance.'
    },
    {
        id: 10,
        title: 'Sales Representative',
        description: 'Identify leads, build relationships, and close deals.',
        location: 'On-site',
        experience: '2+ years',
        jobDescription: 'Present product demonstrations, negotiate contracts, and achieve sales targets.'
    },
    {
        id: 11,
        title: 'Financial Analyst',
        description: 'Analyze financial data and prepare reports.',
        location: 'Hybrid',
        experience: '4+ years',
        jobDescription: 'Develop financial models, evaluate investments, and monitor financial performance.'
    },
    {
        id: 12,
        title: 'Network Administrator',
        description: 'Install and maintain network infrastructure.',
        location: 'On-site',
        experience: '3+ years',
        jobDescription: 'Monitor network performance, troubleshoot issues, and implement security policies.'
    },
    {
        id: 13,
        title: 'Content Writer',
        description: 'Create engaging content for various platforms.',
        location: 'Remote',
        experience: '2+ years',
        jobDescription: 'Write blog posts, articles, and website copy, and optimize content for SEO.'
    },
    {
        id: 14,
        title: 'Quality Assurance Engineer',
        description: 'Develop and execute test plans to ensure software quality.',
        location: 'Hybrid',
        experience: '3+ years',
        jobDescription: 'Identify defects, automate testing, and collaborate with developers to resolve issues.'
    },
    {
        id: 15,
        title: 'Business Analyst',
        description: 'Gather requirements and document business processes.',
        location: 'On-site',
        experience: '4+ years',
        jobDescription: 'Analyze business needs, facilitate communication, and support project implementation.'
    },
    {
        id: 16,
        title: 'Logistics Coordinator',
        description: 'Manage transportation and storage of goods.',
        location: 'Hybrid',
        experience: '2+ years',
        jobDescription: 'Coordinate with suppliers, track shipments, and resolve logistics issues.'
    },
    {
        id: 17,
        title: 'Social Media Manager',
        description: 'Develop and implement social media strategies.',
        location: 'Remote',
        experience: '3+ years',
        jobDescription: 'Create content, monitor analytics, and engage with online communities.'
    },
    {
        id: 18,
        title: 'Research Scientist',
        description: 'Conduct research and experiments in a specific field.',
        location: 'On-site',
        experience: '5+ years',
        jobDescription: 'Analyze data, publish findings, and collaborate with other researchers.'
    }
];

const addCORSHeaders = (response) => {
    return {
        ...response,
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type',
        }
    };
};

exports.handler = async (event, context) => {
    let response;

    if (event.httpMethod === 'OPTIONS') {
        return {
            statusCode: 204,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Max-Age': '86400'
            },
            body: ''
        };
    }

    if (event.httpMethod === 'GET') {
        response = {
            statusCode: 200,
            body: JSON.stringify(careers),
        };
    }

    if (event.httpMethod === 'POST') {
        const newCareer = JSON.parse(event.body);
        newCareer.id = careers.length + 1;
        careers.push(newCareer);
        response = {
            statusCode: 201,
            body: JSON.stringify({ message: 'Career added successfully', career: newCareer }),
        };
    }

    if (event.httpMethod === 'PUT') {
        const careerId = event.queryStringParameters.id;
        const updatedCareer = JSON.parse(event.body);

        const index = careers.findIndex(career => career.id == careerId);
        if (index !== -1) {
            careers[index] = { ...careers[index], ...updatedCareer };
            response = {
                statusCode: 200,
                body: JSON.stringify({ message: 'Career updated successfully', career: careers[index] }),
            };
        } else {
            response = {
                statusCode: 404,
                body: JSON.stringify({ message: 'Career not found' }),
            };
        }
    }

    if (event.httpMethod === 'DELETE') {
        const careerId = event.queryStringParameters.id;
        const index = careers.findIndex(career => career.id == careerId);

        if (index !== -1) {
            careers.splice(index, 1);
            response = {
                statusCode: 200,
                body: JSON.stringify({ message: 'Career deleted successfully' }),
            };
        } else {
            response = {
                statusCode: 404,
                body: JSON.stringify({ message: 'Career not found' }),
            };
        }
    }

    return addCORSHeaders(response);
};